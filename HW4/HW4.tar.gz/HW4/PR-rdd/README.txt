Customize these paths for your environment.
hadoop.root
local.input
local.output
k

1. use "make local" to run the program

2. The top k pageranks and k biggest pagerank value and other required outputs are in both the log and the console output. 

package rp;

public enum CounterEnum {
	TRIANGLE_COUNTER;
}

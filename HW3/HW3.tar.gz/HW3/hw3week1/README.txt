Customize these paths for your environment.
hadoop.root
local.input
local.output
aws.bucket.name
aws.input
aws.output

run the program on aws:
1.put the input file inside the input folder
	I have not add the input file in the tar package. Before running the program, add
it to the 'input' folder.
2.make local1
to run RDD-Group

make local2
to run RDD-R

make local3
to run RDD-F

make local4
to run RDD-A

make local5
to run DSET
